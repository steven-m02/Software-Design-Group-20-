public class RedApple implements GroceryProductFactory{
    @Override
    public void alertUser()
    {
        System.out.println("Created Red Apple");
    }
}
