public class ProductPrice {
    public static void main(String[]args)
    {
        AbstracttheFactory abstracttheFactory= new AbstracttheFactory();
        GroceryProductFactory groceryProductFactory= abstracttheFactory.createGroceryProductFactory("Red Apple");
        groceryProductFactory.alertUser();
    }
}
