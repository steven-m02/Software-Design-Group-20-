public class AbstracttheFactory {
    public GroceryProductFactory createGroceryProductFactory(String channel)
    {
        if(channel==null||channel.isEmpty())
            return null;
        switch(channel){
            case "Red Apple":
            return new RedApple();
            case "Green Apple":
            return new GreenApple();
            case "Bananas":
                return new Bananas();
            default:
                throw new IllegalArgumentException("Product"+channel);
        }
    }
}