public class Bananas implements GroceryProductFactory{
    @Override
    public void alertUser()
    {
        System.out.println("Created Banana");
    }
}
