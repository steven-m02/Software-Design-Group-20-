public class GreenApple implements GroceryProductFactory {
    @Override
    public void alertUser()
    {
        System.out.println("Created Green apple");
    }
}
