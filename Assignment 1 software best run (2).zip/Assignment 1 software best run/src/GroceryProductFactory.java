public interface GroceryProductFactory {
    void alertUser();
}
